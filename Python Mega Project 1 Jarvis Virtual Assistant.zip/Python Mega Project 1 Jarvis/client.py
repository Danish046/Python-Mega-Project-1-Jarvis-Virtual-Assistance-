from openai import OpenAI
# client = OpenAI()


client = OpenAI(
    api_key="sk-..."
)
completion = client.chat.completions.create(
    model = "gpt-3.5-turbo",
    messages = [
        {"role": "user", "content": "Hello!"}
    ]
)
print(completion.choice[0].message.content)




