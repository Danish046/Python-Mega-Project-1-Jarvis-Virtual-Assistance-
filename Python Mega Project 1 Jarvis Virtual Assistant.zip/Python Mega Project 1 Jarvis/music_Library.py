music = {
    
    "jhol": "https://www.youtube.com/watch?v=-2RAq5o5pwc&list=RD-2RAq5o5pwc&start_radio=1",
    "millionaire": "https://www.youtube.com/watch?v=XO8wew38VM8&list=RDXO8wew38VM8&start_radio=1",
    "thodi si daro": "https://www.youtube.com/watch?v=slM5s55Jz0k&list=RDslM5s55Jz0k&index=1",
    "aura" : "https://www.youtube.com/watch?v=-xUkPo2q3zc&list=RD-xUkPo2q3zc&start_radio=1"
    
}

    
