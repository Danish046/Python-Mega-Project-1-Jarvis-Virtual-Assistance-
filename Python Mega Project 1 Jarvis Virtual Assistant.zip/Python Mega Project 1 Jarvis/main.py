import speech_recognition as sr
import webbrowser
import pyttsx3
import music_Library
import requests


recognizer = sr.Recognizer()  
engine = pyttsx3.init()
newsapi = "d68aee7738924236829574525407511b"

def speak(text):
    voices = engine.getProperty("voices")
    engine.setProperty("voice", voices[0].id)  # 0 = male, 1 = female
    engine.setProperty("rate", 170)  # Speed thori normal
    engine.say(text)
    engine.runAndWait()
    
    
def processCommand(c):
    if "open google" in c.lower():
        webbrowser.open("https://www.google.com")
    elif "open facebook" in c.lower():
        webbrowser.open("https://www.facebook.com")
    elif "open youtube" in c.lower():
        webbrowser.open("https://www.youtube.com")
    elif "open linkedin" in c.lower():
        webbrowser.open("https://www.Linkedin.com")    
    elif c.lower().startswith("play"):
        song = c.lower().split(" ")[1]
        link = music_Library.music[song]  
        webbrowser.open(link)
        
    elif "news" in c.lower():
        r = requests.get(f"https://newsapi.org/v2/top-headlines?country=pak&apiKey=API_KEY={newsapi}")
        if r.status_code == 200:
            data = r.json()
            articles = data.get('articles',[]) 
            for article in articles:
                speak(article['title'])     
                
    else:
        # Let OpenAi handel the request 
        pass              
            
        

if __name__ == "__main__":
    speak("Initializing Jarvis....")
    while True:
    #Listen for the wake word "Jarvis"
    #obtain audio from the microphone
    
        r = sr.Recognizer()
        print("recognizing...")

        # recognize speech using google
        try:
            with sr.Microphone() as source:
                print("Listening...")
                audio = r.listen(source, timeout=2, phrase_time_limit=2)
                word = r.recognize_google(audio)
            if word.lower() == "jarvis":
                speak("Yes")
                

                # listen for command
                with sr.Microphone() as source:
                    print("Jarvis Active...")
                    audio = r.listen(source)
                    command = r.recognize_google(audio)

                processCommand(command)
        except Exception as e:
            print("Error:", e)
    
    

    
        
        
        
                
    
